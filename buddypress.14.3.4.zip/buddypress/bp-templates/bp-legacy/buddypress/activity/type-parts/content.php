<?php
/**
 * BuddyPress - Activity content
 *
 * This template is used by `activity/entry.php` and showes any activity type content.
 *
 * @since 10.0.0
 * @version 10.0.0
 */

bp_activity_content_body();
